import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowUpRight, r as Menu, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bzk4WXVX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var categories = [
	"Все",
	"Книги",
	"Медиа",
	"Ловушки",
	"Концепции"
];
var works = [
	{
		id: "character",
		title: "Характер или система?",
		category: "Книги",
		image: "/media/character.jpg",
		alt: "Обложка книги «Характер или система?» Виктора Жарина",
		blurb: "Как институты, идеология, религия и социальный порядок формируют поведение обществ.",
		paragraphs: [
			"Весы на обложке держат две чаши: характер и систему. Ни одна не объясняет человека в одиночку.",
			"Книга смотрит на общество как на связку институтов, идеологии, религии и привычного порядка — и спрашивает, что из этого человек считает своим выбором.",
			"Это не готовая истина, а инструмент: увидеть, где кончается личный нрав и начинается устройство, в котором он живёт."
		],
		focus: "center",
		wide: true
	},
	{
		id: "manipulation",
		title: "Манипуляция сознанием",
		category: "Книги",
		image: "/media/manipulation.jpg",
		alt: "Обложка «Манипуляция сознанием» — как медиасреда превращает эмоцию в идентичность",
		blurb: "Как медиасреда превращает эмоцию в идентичность — архитектура, а не набор трюков.",
		paragraphs: [
			"Мы привыкли думать о манипуляции как о насилии: кто-то сильнее заставляет думать иначе. Современная медиасреда работает иначе.",
			"Она не ломает психику. Она легитимизирует и монетизирует то, что в человеке уже есть, и возвращает это в увеличенном масштабе.",
			"Внимание становится эмоцией, эмоция — интерпретацией, убеждение — идентичностью, а идентичность — войной «своих» против «чужих»."
		],
		focus: "center"
	},
	{
		id: "recruit",
		title: "Механизмы вербовки и её защиты",
		category: "Книги",
		image: "/media/recruit.jpg",
		alt: "Обложка «Механизмы вербовки и её защиты»",
		blurb: "Уязвимости, манипуляции и методология контрвербовочной защиты.",
		paragraphs: [
			"Теоретические основы, оперативные технологии и то, чем на вербовку можно ответить.",
			"Книга собирает уязвимости, по которым человека втягивают в чужой сценарий, и раскладывает защиту не как лозунг, а как последовательность.",
			"Рядом — разговоры о книгах: психология, медиа, общество, философия. Один и тот же вопрос с разных сторон."
		],
		focus: "center"
	},
	{
		id: "library",
		title: "Корпус книг",
		category: "Книги",
		image: "/media/library.jpg",
		alt: "Подборка книг Виктора Жарина: от «Чужого сценария» до «Семьи вне системы»",
		blurb: "Чужой сценарий, Бегство от зрелости, Три народа, Трагедия власти, Контролируемая иллюзия.",
		paragraphs: [
			"Один авторский взгляд, разложенный по книгам: Чужой сценарий, Бегство от зрелости, Главный обман системы, Три народа, Трагедия власти.",
			"Дальше — Чужой сценарий внутри меня, Контролируемая иллюзия и Семья вне системы: от навязанной программы к семье, власти и личной зрелости.",
			"Каждая обложка — отдельный вход. Вместе они держат одну тему: кто пишет сценарий, по которому человек живёт."
		],
		focus: "center",
		wide: true
	},
	{
		id: "media",
		title: "Архитектура медиавоздействия",
		category: "Медиа",
		image: "/media/media-arch.jpg",
		alt: "Схема «Архитектура медиавоздействия»: от внимания аудитории к доверию",
		blurb: "От внимания аудитории к доверию и поведению. Исследовательская концепция разбора эфира.",
		paragraphs: [
			"Авторская концепция для разговора о медиаизмерении: охват и длительность просмотра — только первый слой.",
			"Дальше нужно понять, как контент приобретает значение. Содержание, психика зрителя и социальная среда работают одновременно.",
			"Концепция ложится поверх существующей системы измерения и добавляет уровень мотива, а не подменяет цифры охвата."
		],
		focus: "center"
	},
	{
		id: "blackbox",
		title: "Чёрный ящик зрителя",
		category: "Медиа",
		image: "/media/blackbox.jpg",
		alt: "Схема предела традиционного измерения: мотив скрыт в сознании зрителя",
		blurb: "Мы знаем охваты. Мы не знаем, почему один сюжет рождает доверие, а другой — раздражение.",
		paragraphs: [
			"Традиционное измерение видит факт: охват, продолжительность, выбор канала. Мотив остаётся в «чёрном ящике».",
			"Почему один материал вызывает абсолютное доверие, другой — раздражение, третий — чувство социальной принадлежности?",
			"Вопрос исследования: когда простой просмотр превращается в формирование устойчивых убеждений."
		],
		focus: "center"
	},
	{
		id: "paradigm",
		title: "Три фактора убеждения",
		category: "Медиа",
		image: "/media/paradigm.jpg",
		alt: "Схема устойчивого убеждения на пересечении содержания, психики и среды",
		blurb: "Содержание, личный опыт и социальная среда. В центре — устойчивое убеждение.",
		paragraphs: [
			"Изучать только факт просмотра недостаточно. Нужно видеть, через что медиаконтент становится значимым.",
			"Три опоры: содержание и повторяемость, психологические особенности человека, доверие к источнику и социальный контекст.",
			"Одна и та же информация читается по-разному в зависимости от этих факторов. На их пересечении возникает устойчивое убеждение."
		],
		focus: "center"
	},
	{
		id: "coding",
		title: "Кодирование медиаконтента",
		category: "Медиа",
		image: "/media/coding.jpg",
		alt: "Методичка: шкалы конфликтности и эмоциональных триггеров",
		blurb: "Шкалы конфликта, эмотриггеров и темпа. Протокол, где просмотр ещё не значит доверие.",
		paragraphs: [
			"Методическое приложение к «Архитектуре медиавоздействия»: готовые шкалы для контент-анализа эфира.",
			"Конфликтность от согласия до личного срыва, эмоциональные триггеры от возмущения до эмпатии, темп, клиффхэнгеры, повтор ключевых сообщений.",
			"Важная оговорка: высокая длительность просмотра сама по себе не означает доверия. Зритель может смотреть из любопытства, несогласия или желания следить за конфликтом."
		],
		focus: "top"
	},
	{
		id: "diary",
		title: "Дневник наблюдателя",
		category: "Ловушки",
		image: "/media/diary.jpg",
		alt: "Дневник наблюдателя: визуальные разборы ловушек мышления",
		blurb: "Визуальные разборы ловушек мышления. Пора проснуться и увидеть мир, какой он есть.",
		paragraphs: [
			"Дневник собирает схемы, на которых ловушка мышления становится видимой: не лекция, а разбор.",
			"Пора проснуться и понять мир, какой он на самом деле — не как лозунг, а как привычка смотреть на собственную реакцию со стороны.",
			"Раздел стратегий и концепций держит готовые планы и текстовые исследования природы, институтов и манипуляций."
		],
		focus: "center"
	},
	{
		id: "instincts",
		title: "Древние инстинкты в новой оболочке",
		category: "Ловушки",
		image: "/media/instincts.jpg",
		alt: "Схема сырья медиасреды: справедливость, конфликт, провокация, уязвимость",
		blurb: "Справедливость, конфликт, юмор, зависть, тайное знание. Новыми стали скорость и масштаб.",
		paragraphs: [
			"Механизмы вовлечения строятся на базовых реакциях. Они не новы. Новыми стали скорость, масштаб и экономическая выгода от постоянного усиления.",
			"Сырьё среды: справедливость и возмущение, конфликт, юмор и контраст, уязвимость, иллюзия избранности, провокация гнева.",
			"Спокойный анализ требует работы. Противостояние предлагает проблему, виновника и сторону — поэтому конфликт стабильно побеждает нюанс."
		],
		focus: "top"
	},
	{
		id: "mirror",
		title: "Зеркало, которое увеличивает",
		category: "Концепции",
		image: "/media/mirror.jpg",
		alt: "Введение «Зеркало, которое увеличивает»: сдвиг от насилия к легитимизации",
		blurb: "Система обнаруживает желание, усиливает его и возвращает человеку в большем масштабе.",
		paragraphs: [
			"«Система не заставляет человека делать то, чего он не хочет. Она обнаруживает то, чего он хочет, усиливает это желание и возвращает его в увеличенном масштабе.»",
			"Сети и ток-шоу не изобрели слабостей. Они их обнаружили и начали воспроизводить. Человек говорит: «мне интересен конфликт». Алгоритм отвечает: «хорошо».",
			"Свобода, которая ещё остаётся, живёт в паузе между стимулом и реакцией. Дневник и книги — попытка эту паузу удержать."
		],
		focus: "top"
	},
	{
		id: "digital",
		title: "Мир — это цифровая информация",
		category: "Концепции",
		image: "/media/digital.jpg",
		alt: "Постер «Мир это цифровая информация» с образом человека как сети",
		blurb: "Внимание, эмоции и убеждения становятся точками управления. У человека нет одного кода.",
		paragraphs: [
			"Мир, в котором мы живём, — не только физическое пространство. Это информационная среда, где внимание, эмоции и убеждения становятся точками управления.",
			"Человека можно рассматривать как сложную биологическую и психологическую систему. Память, опыт, потребности и социальные связи работают одновременно.",
			"Метафора «биокомпьютера» здесь не отрицает свободу. У такой системы нет одного простого кода — и именно поэтому её нельзя свести к одному рычагу."
		],
		focus: "center"
	}
];
var skills = [
	{
		n: "01",
		title: "Наблюдение",
		text: "Фиксировать, как среда формирует убеждение, не подменяя факт готовой интерпретацией."
	},
	{
		n: "02",
		title: "Медиакодирование",
		text: "Конфликт, эмоциональные триггеры, темп, повтор и клиффхэнгер — как читаемые признаки."
	},
	{
		n: "03",
		title: "Архитектура влияния",
		text: "Путь от внимания к доверию и поведению, а не коллекция отдельных приёмов."
	},
	{
		n: "04",
		title: "Системный взгляд",
		text: "Институты, идеология и социальный порядок как то, что пишет человеку сценарий."
	},
	{
		n: "05",
		title: "Прикладная психология",
		text: "Язык самонаблюдения без претензии заменить лабораторию полярным ярлыком."
	},
	{
		n: "06",
		title: "Визуальный разбор",
		text: "Схемы, на которых ловушка мышления видна целиком, а не прячется в абзаце."
	},
	{
		n: "07",
		title: "Авторский нарратив",
		text: "Книги как инструменты размышления. Читателю оставляется работа, не вердикт."
	},
	{
		n: "08",
		title: "Разбор ситуации",
		text: "Вопросы, комментарии и личные истории — с ответом, а не с рассылкой лозунгов."
	}
];
var NAV = [
	{
		href: "#about",
		label: "О себе"
	},
	{
		href: "#works",
		label: "Работы"
	},
	{
		href: "#method",
		label: "Метод"
	},
	{
		href: "#skills",
		label: "Навыки"
	},
	{
		href: "#contact",
		label: "Контакт"
	}
];
var TOPICS = [
	"Разбор ситуации",
	"Вопрос по книге",
	"Сотрудничество",
	"Экспертная рассылка"
];
function Portfolio() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [filter, setFilter] = (0, import_react.useState)("Все");
	const [active, setActive] = (0, import_react.useState)(null);
	const dialogRef = (0, import_react.useRef)(null);
	const visible = filter === "Все" ? works : works.filter((work) => work.category === filter);
	(0, import_react.useEffect)(() => {
		const dialog = dialogRef.current;
		if (!dialog) return;
		if (active && !dialog.open) dialog.showModal();
		if (!active && dialog.open) dialog.close();
	}, [active]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#top",
							className: "font-serif text-2xl leading-none font-semibold tracking-tight",
							children: "Жарин"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-7 md:flex",
							"aria-label": "Разделы",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: item.href,
								className: "text-sm text-ink/70 hover:text-ink",
								children: item.label
							}, item.href))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "hidden h-11 items-center bg-ink px-4 text-sm text-paper md:inline-flex active:scale-[0.96]",
							children: "Написать"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center md:hidden",
							"aria-expanded": open,
							"aria-controls": "mobile-nav",
							onClick: () => setOpen((value) => !value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: open ? "Закрыть меню" : "Открыть меню"
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { "aria-hidden": true })]
						})
					]
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					id: "mobile-nav",
					className: "border-t border-line px-5 py-3 md:hidden",
					"aria-label": "Разделы",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "flex h-12 items-center border-b border-line text-lg font-serif",
						onClick: () => setOpen(false),
						children: item.label
					}, item.href))
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl items-end gap-10 px-5 pt-14 pb-16 lg:grid-cols-12 lg:pt-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "kicker",
									children: "Дневник наблюдателя"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "display mt-4 text-6xl text-ink sm:text-7xl lg:text-8xl",
									children: [
										"Виктор",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Жарин"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-xl text-lg leading-relaxed text-ink/75",
									children: "Исследователь человеческой природы. Изучаю, как формируются убеждения, как среда меняет мышление и почему люди иногда действуют вопреки собственным интересам."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl font-serif text-2xl leading-snug text-ink italic",
									children: "Пора проснуться и понять мир, какой он на самом деле."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#works",
										className: "inline-flex h-12 items-center bg-cinnabar px-5 text-sm font-medium text-paper active:scale-[0.96]",
										children: "Смотреть работы"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#method",
										className: "inline-flex h-12 items-center border border-ink/20 px-5 text-sm active:scale-[0.96]",
										children: "О методе"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "lg:col-span-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/character.jpg",
								alt: "Обложка книги Виктора Жарина «Характер или система?»",
								className: "w-full border border-line"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
								className: "mt-3 flex items-baseline justify-between gap-4 text-sm text-ink/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Характер или система?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Книги · 2026" })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "about",
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-12 lg:py-24",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "kicker",
									children: "О себе"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display mt-3 text-5xl",
									children: "Не готовые истины, а инструменты"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7 lg:col-start-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "drop text-lg leading-relaxed text-ink/85",
										children: "Виктор Жарин — исследователь человеческой природы. Через авторские концепции, книги и аналитические разборы я показываю скрытые механизмы поведения, влияния информации и взаимодействия человека с обществом. Работа основана на самостоятельном анализе, наблюдениях и систематизации идей."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 text-lg leading-relaxed text-ink/75",
										children: "Мастер обучения и исследования человеческой природы и сферы её существования. Читателю предлагается не вердикт, а способ смотреть: на государство как на систему людей, информации и коллективных представлений — и на себя как на участника собственной истории."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
										className: "mt-10 grid gap-6 border-t border-line pt-6 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "kicker",
												children: "Поле"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-2 text-sm leading-relaxed",
												children: "Прикладная психология и медиаанализ"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "kicker",
												children: "Форма"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-2 text-sm leading-relaxed",
												children: "Книги, схемы, разбор ситуаций"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "kicker",
												children: "Связь"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-2 text-sm leading-relaxed",
												children: "Telegram, WhatsApp, почта"
											})] })
										]
									})
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "works",
						className: "border-t border-line bg-ink text-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5 py-16 lg:py-24",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-widest text-paper/80 uppercase",
										children: "Работы"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "display mt-3 text-5xl sm:text-6xl",
										children: "Картотека материалов"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-sm text-sm leading-relaxed text-paper/75",
										children: "Наведите на карточку — откроется короткий разбор. Нажмите, чтобы прочитать, о чём материал целиком."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 flex flex-wrap gap-2",
									role: "group",
									"aria-label": "Фильтр по категориям",
									children: categories.map((category) => {
										const pressed = filter === category;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": pressed,
											onClick: () => setFilter(category),
											className: "h-11 px-4 text-sm active:scale-[0.96] " + (pressed ? "bg-paper text-ink" : "border border-paper/40 text-paper hover:bg-paper/10"),
											children: category
										}, category);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 text-sm text-paper/75",
									"aria-live": "polite",
									children: [
										visible.length,
										" ",
										visible.length === 1 ? "материал" : visible.length < 5 ? "материала" : "материалов"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
									children: visible.map((work, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: work.wide ? "lg:col-span-2" : void 0,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setActive(work),
											className: "group relative block w-full overflow-hidden border border-paper/20 text-left active:scale-[0.96]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: work.wide ? "card-frame-wide block" : "card-frame block",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: work.image,
													alt: "",
													className: "h-full w-full object-cover transition duration-500 group-hover:scale-105 " + (work.focus === "top" ? "object-top" : "object-center")
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "absolute inset-x-0 bottom-0 bg-ink p-5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center justify-between text-xs font-semibold tracking-widest text-paper/75 uppercase",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: work.category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-serif text-base font-medium tracking-normal text-paper/80 normal-case",
															children: String(index + 1).padStart(2, "0")
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "display mt-2 block text-3xl text-paper sm:text-4xl",
														children: work.title
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "reveal mt-3 block text-sm leading-relaxed text-paper/90",
														children: work.blurb
													})
												]
											})]
										})
									}, work.id))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-line",
						"aria-label": "Дневник наблюдателя",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl items-center gap-8 px-5 py-16 lg:grid-cols-2 lg:py-20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/diary.jpg",
								alt: "Заставка дневника наблюдателя: визуальные разборы ловушек мышления",
								className: "w-full border border-line"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "kicker",
									children: "Дневник"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display mt-3 text-5xl",
									children: "Визуальные разборы ловушек мышления"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-lg leading-relaxed text-ink/75",
									children: "Стратегии и концепции — готовые планы и текстовые исследования природы, институтов и манипуляций. Закрытая экспертная переписка для тех, кто хочет быть внутри актуальных разборов, а не на поверхности ленты."
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "method",
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5 py-16 lg:py-24",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "kicker",
									children: "Метод"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display mt-3 max-w-3xl text-5xl sm:text-6xl",
									children: "От ритуала к тому, как человек сам считает идею своей"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-12 grid gap-12 lg:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-3xl",
											children: "Архитектура современной системы"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "На государство можно смотреть не только как на набор учреждений, но и как на сложное взаимодействие людей, информации, ценностей и коллективных представлений."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "Старые формы уже не объясняют происходящее. Человек хочет не просто подчиняться внешнему авторитету — он хочет понимать и ощущать себя участником собственной истории."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "Вопрос уже не в том, как заставить принять идею. Важнее, почему человек сам начинает считать её значимой: какая среда собрана вокруг него и какие модели поведения кажутся естественными."
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-3xl",
											children: "Человек как сложная система"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "Память, эмоции, опыт, потребности, убеждения, связи и способность решать работают одновременно. Метафора биокомпьютера описывает эту сложность, а не отменяет свободу."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "Одного кода нет. На решение влияют прошлый опыт, ценности, окружение, информация, ожидания и собственный образ будущего."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 leading-relaxed text-ink/80",
											children: "Понимание этих механизмов нужно не для давления, а для другой задачи: условий, в которых человек способен осознанно участвовать в жизни общества."
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
									className: "mt-14 grid items-center gap-8 border-t border-line pt-10 lg:grid-cols-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
										className: "lg:col-span-7",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-serif text-3xl leading-snug sm:text-4xl",
											children: "«Система не заставляет человека делать то, чего он не хочет. Она обнаруживает то, чего он хочет, усиливает это желание и возвращает его в увеличенном масштабе.»"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "mt-4 text-sm text-ink/60",
											children: "— Виктор Жарин"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/media/quote.jpg",
										alt: "Карточка с цитатой Виктора Жарина о системе, которая усиливает желание",
										className: "w-full border border-line lg:col-span-5"
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "skills",
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5 py-16 lg:py-24",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "Навыки"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "display mt-3 text-5xl",
										children: "Чем занят разбор"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-ink/70",
										children: "Оценивать эту работу по шкале «наука или пустая болтовня» в полярных категориях было бы неточно. Это поле популярной и прикладной психологии."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-12 divide-y divide-line border-y border-line",
								children: skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "grid gap-2 py-6 sm:grid-cols-12 sm:items-baseline sm:gap-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-serif text-2xl text-cinnabar sm:col-span-1",
											children: skill.n
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-serif text-3xl sm:col-span-4",
											children: skill.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-ink/75 sm:col-span-7",
											children: skill.text
										})
									]
								}, skill.n))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "contact",
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 lg:grid-cols-12 lg:py-24",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "kicker",
										children: "Контакт"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "display mt-3 text-5xl",
										children: "Пишите — разберу ситуацию"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 leading-relaxed text-ink/75",
										children: "Вопросы, комментарии и предложения. Отвечу, разберу вашу ситуацию и дам совет по существу, без готовой проповеди."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "mt-8 space-y-3 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												className: "inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4",
												href: "https://t.me/Zharinviktor",
												target: "_blank",
												rel: "noreferrer",
												children: ["Telegram · t.me/Zharinviktor ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
													className: "size-4",
													"aria-hidden": true
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												className: "inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4",
												href: "https://wa.me/4915214309066",
												target: "_blank",
												rel: "noreferrer",
												children: ["WhatsApp · +49 152 14309066 ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
													className: "size-4",
													"aria-hidden": true
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												className: "inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4",
												href: "mailto:viktorzarin66@gmail.com",
												children: ["viktorzarin66@gmail.com ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
													className: "size-4",
													"aria-hidden": true
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												className: "inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4",
												href: "https://www.youtube.com/@ВикторЖарин-т2п",
												target: "_blank",
												rel: "noreferrer",
												children: ["YouTube · @ВикторЖарин-т2п ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
													className: "size-4",
													"aria-hidden": true
												})]
											}) })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "bg-ink text-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "display text-6xl",
								children: "Жарин"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-sm text-sm leading-relaxed text-paper/75",
								children: "Все права защищены. Подписывайтесь на экспертную переписку, чтобы первыми узнавать о новых материалах и стратегиях."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-widest text-paper/80 uppercase",
								children: "Разделы"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-2 text-sm",
								children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: item.href,
									className: "text-paper/80 hover:text-paper",
									children: item.label
								}) }, item.href))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-widest text-paper/80 uppercase",
								children: "Рассылка"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, {})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-paper/25",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-sm text-paper/70 sm:flex-row sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"© ",
							(/* @__PURE__ */ new Date()).getFullYear(),
							" Виктор Жарин"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#top",
							className: "hover:text-paper",
							children: "Наверх"
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dialog", {
				ref: dialogRef,
				className: "sheet",
				"aria-labelledby": "work-title",
				onClose: () => setActive(null),
				onClick: (event) => {
					const rect = event.currentTarget.getBoundingClientRect();
					if (!(event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom)) event.currentTarget.close();
				},
				children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: active.image,
						alt: active.alt,
						className: "w-full bg-ink " + (active.focus === "top" ? "object-contain object-top md:min-h-full" : "h-full object-cover")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative p-6 sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "absolute top-4 right-4 inline-flex size-11 items-center justify-center",
								onClick: () => dialogRef.current?.close(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Закрыть"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": true })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: active.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "work-title",
								className: "display mt-3 pr-10 text-4xl sm:text-5xl",
								children: active.title
							}),
							active.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 leading-relaxed text-ink/80",
								children: paragraph
							}, paragraph.slice(0, 24))),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: "mt-8 inline-flex h-12 items-center bg-ink px-5 text-sm text-paper",
								onClick: () => dialogRef.current?.close(),
								children: "Спросить об этом материале"
							})
						]
					})]
				}) : null
			})
		]
	});
}
function ContactForm() {
	const [error, setError] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(null);
	const errorId = (0, import_react.useId)();
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const email = String(data.get("email") ?? "").trim();
		const topic = String(data.get("topic") ?? "").trim();
		const message = String(data.get("message") ?? "").trim();
		if (name.length < 2) {
			setError("Как к вам обращаться? Нужно хотя бы два символа.");
			setSent(null);
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
			setError("Похоже, в почте опечатка.");
			setSent(null);
			return;
		}
		if (!topic) {
			setError("Выберите тему, чтобы письмо не потерялось.");
			setSent(null);
			return;
		}
		if (message.length < 12) {
			setError("Напишите немного подробнее — хотя бы пару фраз.");
			setSent(null);
			return;
		}
		const subject = encodeURIComponent(`${topic} — ${name}`);
		const body = encodeURIComponent(`${message}\n\n— ${name}\n${email}`);
		setError("");
		setSent(`mailto:viktorzarin66@gmail.com?subject=${subject}&body=${body}`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "border border-line bg-paper p-5 sm:p-7 lg:col-span-7",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Имя",
					name: "name",
					autoComplete: "name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Почта",
					name: "email",
					type: "email",
					autoComplete: "email"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm",
				children: ["Тема", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					name: "topic",
					defaultValue: "",
					className: "mt-2 h-12 w-full border border-line bg-paper px-3 text-base",
					suppressHydrationWarning: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						disabled: true,
						children: "Выберите"
					}), TOPICS.map((topic) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: topic,
						children: topic
					}, topic))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm",
				children: ["Сообщение", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "message",
					rows: 6,
					className: "mt-2 w-full border border-line bg-paper px-3 py-3 text-base leading-relaxed",
					suppressHydrationWarning: true
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: errorId,
				className: "mt-4 text-sm text-cinnabar",
				role: "alert",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "mt-5 inline-flex h-12 items-center bg-cinnabar px-5 text-sm font-medium text-paper active:scale-[0.96]",
				children: "Собрать письмо"
			}),
			sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm leading-relaxed text-ink/80",
				children: [
					"Черновик готов.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline decoration-cinnabar underline-offset-4",
						href: sent,
						children: "Открыть в почте"
					}),
					". Если почта не откроется, напишите в Telegram или WhatsApp — контакты слева."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink/55",
				children: "Письмо не уходит само: откроется ваша почта с уже вписанным текстом на viktorzarin66@gmail.com."
			})
		]
	});
}
function Field({ label, name, type = "text", autoComplete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			type,
			autoComplete,
			suppressHydrationWarning: true,
			className: "mt-2 h-12 w-full border border-line bg-paper px-3 text-base"
		})]
	});
}
function Newsletter() {
	const [note, setNote] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const email = String(data.get("newsletter") ?? "").trim();
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
			setNote("Укажите почту, на которую присылать материалы.");
			return;
		}
		const href = `mailto:viktorzarin66@gmail.com?subject=${encodeURIComponent("Экспертная рассылка")}&body=${encodeURIComponent(`Прошу включить в экспертную рассылку.\n\n${email}`)}`;
		setNote(href);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mt-4",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-paper/80",
				children: ["Почта для новых разборов", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "newsletter",
					type: "email",
					autoComplete: "email",
					className: "mt-2 h-12 w-full border border-paper/40 bg-transparent px-3 text-paper placeholder:text-paper/60",
					placeholder: "you@mail.com",
					suppressHydrationWarning: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "mt-3 inline-flex h-11 items-center border border-paper/50 px-4 text-sm text-paper active:scale-[0.96]",
				children: "Оставить заявку"
			}),
			note.startsWith("mailto:") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-paper/75",
				children: [
					"Заявка собрана.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline underline-offset-4",
						href: note,
						children: "Подтвердить письмом"
					}),
					"."
				]
			}) : note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-cinnabar",
				role: "alert",
				children: note
			}) : null
		]
	});
}
var SplitComponent = Portfolio;
//#endregion
export { SplitComponent as component };
