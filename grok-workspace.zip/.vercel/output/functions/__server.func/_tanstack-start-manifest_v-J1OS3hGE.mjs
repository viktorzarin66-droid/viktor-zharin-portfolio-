//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-J1OS3hGE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DFQWj64B.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DFQWj64B.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BDv0teOg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
