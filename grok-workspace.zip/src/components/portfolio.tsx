import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { categories, skills, works, type Filter, type Work } from "@/data/works";

const NAV = [
  { href: "#about", label: "О себе" },
  { href: "#works", label: "Работы" },
  { href: "#method", label: "Метод" },
  { href: "#skills", label: "Навыки" },
  { href: "#contact", label: "Контакт" },
];

const TOPICS = ["Разбор ситуации", "Вопрос по книге", "Сотрудничество", "Экспертная рассылка"];

export function Portfolio() {
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<Filter>("Все");
  const [active, setActive] = useState<Work | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);

  const visible = filter === "Все" ? works : works.filter((work) => work.category === filter);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (active && !dialog.open) dialog.showModal();
    if (!active && dialog.open) dialog.close();
  }, [active]);

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <a href="#top" className="font-serif text-2xl leading-none font-semibold tracking-tight">
            Жарин
          </a>
          <nav className="hidden items-center gap-7 md:flex" aria-label="Разделы">
            {NAV.map((item) => (
              <a key={item.href} href={item.href} className="text-sm text-ink/70 hover:text-ink">
                {item.label}
              </a>
            ))}
          </nav>
          <a
            href="#contact"
            className="hidden h-11 items-center bg-ink px-4 text-sm text-paper md:inline-flex active:scale-[0.96]"
          >
            Написать
          </a>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((value) => !value)}
          >
            <span className="sr-only">{open ? "Закрыть меню" : "Открыть меню"}</span>
            {open ? <X aria-hidden /> : <Menu aria-hidden />}
          </button>
        </div>
        {open ? (
          <nav id="mobile-nav" className="border-t border-line px-5 py-3 md:hidden" aria-label="Разделы">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="flex h-12 items-center border-b border-line text-lg font-serif"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </nav>
        ) : null}
      </header>

      <main id="top">
        <section className="mx-auto grid max-w-6xl items-end gap-10 px-5 pt-14 pb-16 lg:grid-cols-12 lg:pt-20">
          <div className="lg:col-span-7">
            <p className="kicker">Дневник наблюдателя</p>
            <h1 className="display mt-4 text-6xl text-ink sm:text-7xl lg:text-8xl">
              Виктор
              <br />
              Жарин
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink/75">
              Исследователь человеческой природы. Изучаю, как формируются убеждения, как среда
              меняет мышление и почему люди иногда действуют вопреки собственным интересам.
            </p>
            <p className="mt-4 max-w-xl font-serif text-2xl leading-snug text-ink italic">
              Пора проснуться и понять мир, какой он на самом деле.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#works"
                className="inline-flex h-12 items-center bg-cinnabar px-5 text-sm font-medium text-paper active:scale-[0.96]"
              >
                Смотреть работы
              </a>
              <a
                href="#method"
                className="inline-flex h-12 items-center border border-ink/20 px-5 text-sm active:scale-[0.96]"
              >
                О методе
              </a>
            </div>
          </div>
          <figure className="lg:col-span-5">
            <img
              src="/media/character.jpg"
              alt="Обложка книги Виктора Жарина «Характер или система?»"
              className="w-full border border-line"
            />
            <figcaption className="mt-3 flex items-baseline justify-between gap-4 text-sm text-ink/60">
              <span>Характер или система?</span>
              <span>Книги · 2026</span>
            </figcaption>
          </figure>
        </section>

        <section id="about" className="border-t border-line">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-12 lg:py-24">
            <div className="lg:col-span-4">
              <p className="kicker">О себе</p>
              <h2 className="display mt-3 text-5xl">Не готовые истины, а инструменты</h2>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <p className="drop text-lg leading-relaxed text-ink/85">
                Виктор Жарин — исследователь человеческой природы. Через авторские концепции, книги
                и аналитические разборы я показываю скрытые механизмы поведения, влияния информации
                и взаимодействия человека с обществом. Работа основана на самостоятельном анализе,
                наблюдениях и систематизации идей.
              </p>
              <p className="mt-5 text-lg leading-relaxed text-ink/75">
                Мастер обучения и исследования человеческой природы и сферы её существования.
                Читателю предлагается не вердикт, а способ смотреть: на государство как на систему
                людей, информации и коллективных представлений — и на себя как на участника
                собственной истории.
              </p>
              <dl className="mt-10 grid gap-6 border-t border-line pt-6 sm:grid-cols-3">
                <div>
                  <dt className="kicker">Поле</dt>
                  <dd className="mt-2 text-sm leading-relaxed">Прикладная психология и медиаанализ</dd>
                </div>
                <div>
                  <dt className="kicker">Форма</dt>
                  <dd className="mt-2 text-sm leading-relaxed">Книги, схемы, разбор ситуаций</dd>
                </div>
                <div>
                  <dt className="kicker">Связь</dt>
                  <dd className="mt-2 text-sm leading-relaxed">Telegram, WhatsApp, почта</dd>
                </div>
              </dl>
            </div>
          </div>
        </section>

        <section id="works" className="border-t border-line bg-ink text-paper">
          <div className="mx-auto max-w-6xl px-5 py-16 lg:py-24">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-xs font-semibold tracking-widest text-paper/80 uppercase">Работы</p>
                <h2 className="display mt-3 text-5xl sm:text-6xl">Картотека материалов</h2>
              </div>
              <p className="max-w-sm text-sm leading-relaxed text-paper/75">
                Наведите на карточку — откроется короткий разбор. Нажмите, чтобы прочитать, о чём
                материал целиком.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-2" role="group" aria-label="Фильтр по категориям">
              {categories.map((category) => {
                const pressed = filter === category;
                return (
                  <button
                    key={category}
                    type="button"
                    aria-pressed={pressed}
                    onClick={() => setFilter(category)}
                    className={
                      "h-11 px-4 text-sm active:scale-[0.96] " +
                      (pressed ? "bg-paper text-ink" : "border border-paper/40 text-paper hover:bg-paper/10")
                    }
                  >
                    {category}
                  </button>
                );
              })}
            </div>
            <p className="mt-4 text-sm text-paper/75" aria-live="polite">
              {visible.length}{" "}
              {visible.length === 1 ? "материал" : visible.length < 5 ? "материала" : "материалов"}
            </p>

            <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {visible.map((work, index) => (
                <li key={work.id} className={work.wide ? "lg:col-span-2" : undefined}>
                  <button
                    type="button"
                    onClick={() => setActive(work)}
                    className="group relative block w-full overflow-hidden border border-paper/20 text-left active:scale-[0.96]"
                  >
                    <span className={work.wide ? "card-frame-wide block" : "card-frame block"}>
                      <img
                        src={work.image}
                        alt=""
                        className={
                          "h-full w-full object-cover transition duration-500 group-hover:scale-105 " +
                          (work.focus === "top" ? "object-top" : "object-center")
                        }
                      />
                    </span>
                    <span className="absolute inset-x-0 bottom-0 bg-ink p-5">
                      <span className="flex items-center justify-between text-xs font-semibold tracking-widest text-paper/75 uppercase">
                        <span>{work.category}</span>
                        <span className="font-serif text-base font-medium tracking-normal text-paper/80 normal-case">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                      </span>
                      <span className="display mt-2 block text-3xl text-paper sm:text-4xl">{work.title}</span>
                      <span className="reveal mt-3 block text-sm leading-relaxed text-paper/90">{work.blurb}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="border-t border-line" aria-label="Дневник наблюдателя">
          <div className="mx-auto grid max-w-6xl items-center gap-8 px-5 py-16 lg:grid-cols-2 lg:py-20">
            <img
              src="/media/diary.jpg"
              alt="Заставка дневника наблюдателя: визуальные разборы ловушек мышления"
              className="w-full border border-line"
            />
            <div>
              <p className="kicker">Дневник</p>
              <h2 className="display mt-3 text-5xl">Визуальные разборы ловушек мышления</h2>
              <p className="mt-5 text-lg leading-relaxed text-ink/75">
                Стратегии и концепции — готовые планы и текстовые исследования природы, институтов
                и манипуляций. Закрытая экспертная переписка для тех, кто хочет быть внутри
                актуальных разборов, а не на поверхности ленты.
              </p>
            </div>
          </div>
        </section>

        <section id="method" className="border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-16 lg:py-24">
            <p className="kicker">Метод</p>
            <h2 className="display mt-3 max-w-3xl text-5xl sm:text-6xl">
              От ритуала к тому, как человек сам считает идею своей
            </h2>
            <div className="mt-12 grid gap-12 lg:grid-cols-2">
              <article>
                <h3 className="font-serif text-3xl">Архитектура современной системы</h3>
                <p className="mt-4 leading-relaxed text-ink/80">
                  На государство можно смотреть не только как на набор учреждений, но и как на
                  сложное взаимодействие людей, информации, ценностей и коллективных представлений.
                </p>
                <p className="mt-4 leading-relaxed text-ink/80">
                  Старые формы уже не объясняют происходящее. Человек хочет не просто подчиняться
                  внешнему авторитету — он хочет понимать и ощущать себя участником собственной
                  истории.
                </p>
                <p className="mt-4 leading-relaxed text-ink/80">
                  Вопрос уже не в том, как заставить принять идею. Важнее, почему человек сам
                  начинает считать её значимой: какая среда собрана вокруг него и какие модели
                  поведения кажутся естественными.
                </p>
              </article>
              <article>
                <h3 className="font-serif text-3xl">Человек как сложная система</h3>
                <p className="mt-4 leading-relaxed text-ink/80">
                  Память, эмоции, опыт, потребности, убеждения, связи и способность решать
                  работают одновременно. Метафора биокомпьютера описывает эту сложность, а не
                  отменяет свободу.
                </p>
                <p className="mt-4 leading-relaxed text-ink/80">
                  Одного кода нет. На решение влияют прошлый опыт, ценности, окружение, информация,
                  ожидания и собственный образ будущего.
                </p>
                <p className="mt-4 leading-relaxed text-ink/80">
                  Понимание этих механизмов нужно не для давления, а для другой задачи: условий, в
                  которых человек способен осознанно участвовать в жизни общества.
                </p>
              </article>
            </div>
            <figure className="mt-14 grid items-center gap-8 border-t border-line pt-10 lg:grid-cols-12">
              <blockquote className="lg:col-span-7">
                <p className="font-serif text-3xl leading-snug sm:text-4xl">
                  «Система не заставляет человека делать то, чего он не хочет. Она обнаруживает то,
                  чего он хочет, усиливает это желание и возвращает его в увеличенном масштабе.»
                </p>
                <figcaption className="mt-4 text-sm text-ink/60">— Виктор Жарин</figcaption>
              </blockquote>
              <img
                src="/media/quote.jpg"
                alt="Карточка с цитатой Виктора Жарина о системе, которая усиливает желание"
                className="w-full border border-line lg:col-span-5"
              />
            </figure>
          </div>
        </section>

        <section id="skills" className="border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-16 lg:py-24">
            <div className="max-w-2xl">
              <p className="kicker">Навыки</p>
              <h2 className="display mt-3 text-5xl">Чем занят разбор</h2>
              <p className="mt-4 text-ink/70">
                Оценивать эту работу по шкале «наука или пустая болтовня» в полярных категориях
                было бы неточно. Это поле популярной и прикладной психологии.
              </p>
            </div>
            <ol className="mt-12 divide-y divide-line border-y border-line">
              {skills.map((skill) => (
                <li key={skill.n} className="grid gap-2 py-6 sm:grid-cols-12 sm:items-baseline sm:gap-6">
                  <span className="font-serif text-2xl text-cinnabar sm:col-span-1">{skill.n}</span>
                  <h3 className="font-serif text-3xl sm:col-span-4">{skill.title}</h3>
                  <p className="text-ink/75 sm:col-span-7">{skill.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="contact" className="border-t border-line">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 lg:grid-cols-12 lg:py-24">
            <div className="lg:col-span-5">
              <p className="kicker">Контакт</p>
              <h2 className="display mt-3 text-5xl">Пишите — разберу ситуацию</h2>
              <p className="mt-4 leading-relaxed text-ink/75">
                Вопросы, комментарии и предложения. Отвечу, разберу вашу ситуацию и дам совет по
                существу, без готовой проповеди.
              </p>
              <ul className="mt-8 space-y-3 text-sm">
                <li>
                  <a className="inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4" href="https://t.me/Zharinviktor" target="_blank" rel="noreferrer">
                    Telegram · t.me/Zharinviktor <ArrowUpRight className="size-4" aria-hidden />
                  </a>
                </li>
                <li>
                  <a className="inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4" href="https://wa.me/4915214309066" target="_blank" rel="noreferrer">
                    WhatsApp · +49 152 14309066 <ArrowUpRight className="size-4" aria-hidden />
                  </a>
                </li>
                <li>
                  <a className="inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4" href="mailto:viktorzarin66@gmail.com">
                    viktorzarin66@gmail.com <ArrowUpRight className="size-4" aria-hidden />
                  </a>
                </li>
                <li>
                  <a
                    className="inline-flex items-center gap-2 underline decoration-cinnabar underline-offset-4"
                    href="https://www.youtube.com/@ВикторЖарин-т2п"
                    target="_blank"
                    rel="noreferrer"
                  >
                    YouTube · @ВикторЖарин-т2п <ArrowUpRight className="size-4" aria-hidden />
                  </a>
                </li>
              </ul>
            </div>
            <ContactForm />
          </div>
        </section>
      </main>

      <footer className="bg-ink text-paper">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="display text-6xl">Жарин</p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-paper/75">
              Все права защищены. Подписывайтесь на экспертную переписку, чтобы первыми узнавать о
              новых материалах и стратегиях.
            </p>
          </div>
          <div className="lg:col-span-3">
            <p className="text-xs font-semibold tracking-widest text-paper/80 uppercase">Разделы</p>
            <ul className="mt-4 space-y-2 text-sm">
              {NAV.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="text-paper/80 hover:text-paper">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div className="lg:col-span-4">
            <p className="text-xs font-semibold tracking-widest text-paper/80 uppercase">Рассылка</p>
            <Newsletter />
          </div>
        </div>
        <div className="border-t border-paper/25">
          <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-sm text-paper/70 sm:flex-row sm:justify-between">
            <p>© {new Date().getFullYear()} Виктор Жарин</p>
            <a href="#top" className="hover:text-paper">
              Наверх
            </a>
          </div>
        </div>
      </footer>

      <dialog
        ref={dialogRef}
        className="sheet"
        aria-labelledby="work-title"
        onClose={() => setActive(null)}
        onClick={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const inside =
            event.clientX >= rect.left &&
            event.clientX <= rect.right &&
            event.clientY >= rect.top &&
            event.clientY <= rect.bottom;
          if (!inside) event.currentTarget.close();
        }}
      >
        {active ? (
          <div className="grid md:grid-cols-2">
            <img
              src={active.image}
              alt={active.alt}
              className={"w-full bg-ink " + (active.focus === "top" ? "object-contain object-top md:min-h-full" : "h-full object-cover")}
            />
            <div className="relative p-6 sm:p-8">
              <button
                type="button"
                className="absolute top-4 right-4 inline-flex size-11 items-center justify-center"
                onClick={() => dialogRef.current?.close()}
              >
                <span className="sr-only">Закрыть</span>
                <X aria-hidden />
              </button>
              <p className="kicker">{active.category}</p>
              <h2 id="work-title" className="display mt-3 pr-10 text-4xl sm:text-5xl">
                {active.title}
              </h2>
              {active.paragraphs.map((paragraph) => (
                <p key={paragraph.slice(0, 24)} className="mt-4 leading-relaxed text-ink/80">
                  {paragraph}
                </p>
              ))}
              <a
                href="#contact"
                className="mt-8 inline-flex h-12 items-center bg-ink px-5 text-sm text-paper"
                onClick={() => dialogRef.current?.close()}
              >
                Спросить об этом материале
              </a>
            </div>
          </div>
        ) : null}
      </dialog>
    </div>
  );
}

function ContactForm() {
  const [error, setError] = useState("");
  const [sent, setSent] = useState<string | null>(null);
  const errorId = useId();

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const topic = String(data.get("topic") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    if (name.length < 2) {
      setError("Как к вам обращаться? Нужно хотя бы два символа.");
      setSent(null);
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Похоже, в почте опечатка.");
      setSent(null);
      return;
    }
    if (!topic) {
      setError("Выберите тему, чтобы письмо не потерялось.");
      setSent(null);
      return;
    }
    if (message.length < 12) {
      setError("Напишите немного подробнее — хотя бы пару фраз.");
      setSent(null);
      return;
    }
    const subject = encodeURIComponent(`${topic} — ${name}`);
    const body = encodeURIComponent(`${message}\n\n— ${name}\n${email}`);
    setError("");
    setSent(`mailto:viktorzarin66@gmail.com?subject=${subject}&body=${body}`);
  }

  return (
    <form onSubmit={onSubmit} className="border border-line bg-paper p-5 sm:p-7 lg:col-span-7" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Имя" name="name" autoComplete="name" />
        <Field label="Почта" name="email" type="email" autoComplete="email" />
      </div>
      <label className="mt-4 block text-sm">
        Тема
        <select
          name="topic"
          defaultValue=""
          className="mt-2 h-12 w-full border border-line bg-paper px-3 text-base"
          suppressHydrationWarning
        >
          <option value="" disabled>
            Выберите
          </option>
          {TOPICS.map((topic) => (
            <option key={topic} value={topic}>
              {topic}
            </option>
          ))}
        </select>
      </label>
      <label className="mt-4 block text-sm">
        Сообщение
        <textarea
          name="message"
          rows={6}
          className="mt-2 w-full border border-line bg-paper px-3 py-3 text-base leading-relaxed"
          suppressHydrationWarning
        />
      </label>
      {error ? (
        <p id={errorId} className="mt-4 text-sm text-cinnabar" role="alert">
          {error}
        </p>
      ) : null}
      <button
        type="submit"
        className="mt-5 inline-flex h-12 items-center bg-cinnabar px-5 text-sm font-medium text-paper active:scale-[0.96]"
      >
        Собрать письмо
      </button>
      {sent ? (
        <p className="mt-4 text-sm leading-relaxed text-ink/80">
          Черновик готов.{" "}
          <a className="underline decoration-cinnabar underline-offset-4" href={sent}>
            Открыть в почте
          </a>
          . Если почта не откроется, напишите в Telegram или WhatsApp — контакты слева.
        </p>
      ) : (
        <p className="mt-4 text-sm text-ink/55">
          Письмо не уходит само: откроется ваша почта с уже вписанным текстом на viktorzarin66@gmail.com.
        </p>
      )}
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  autoComplete,
}: {
  label: string;
  name: string;
  type?: string;
  autoComplete?: string;
}) {
  return (
    <label className="block text-sm">
      {label}
      <input
        name={name}
        type={type}
        autoComplete={autoComplete}
        suppressHydrationWarning
        className="mt-2 h-12 w-full border border-line bg-paper px-3 text-base"
      />
    </label>
  );
}

function Newsletter() {
  const [note, setNote] = useState("");

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get("newsletter") ?? "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setNote("Укажите почту, на которую присылать материалы.");
      return;
    }
    const href = `mailto:viktorzarin66@gmail.com?subject=${encodeURIComponent("Экспертная рассылка")}&body=${encodeURIComponent(`Прошу включить в экспертную рассылку.\n\n${email}`)}`;
    setNote(href);
  }

  return (
    <form onSubmit={onSubmit} className="mt-4" noValidate>
      <label className="block text-sm text-paper/80">
        Почта для новых разборов
        <input
          name="newsletter"
          type="email"
          autoComplete="email"
          className="mt-2 h-12 w-full border border-paper/40 bg-transparent px-3 text-paper placeholder:text-paper/60"
          placeholder="you@mail.com"
          suppressHydrationWarning
        />
      </label>
      <button
        type="submit"
        className="mt-3 inline-flex h-11 items-center border border-paper/50 px-4 text-sm text-paper active:scale-[0.96]"
      >
        Оставить заявку
      </button>
      {note.startsWith("mailto:") ? (
        <p className="mt-3 text-sm text-paper/75">
          Заявка собрана.{" "}
          <a className="underline underline-offset-4" href={note}>
            Подтвердить письмом
          </a>
          .
        </p>
      ) : note ? (
        <p className="mt-3 text-sm text-cinnabar" role="alert">
          {note}
        </p>
      ) : null}
    </form>
  );
}
